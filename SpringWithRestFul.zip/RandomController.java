package org.hm.controller;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

import org.hm.bean.RandomVO;
import org.hm.handler.GenerateRandom;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

public class RandomController {
	@RequestMapping(value = "/randomData", method = RequestMethod.GET,headers="Accept=application/json")
	public List<Integer> getRandomDataList()
	{
		
			  
			  GenerateRandom rando = new GenerateRandom();
			  RandomVO random1=new RandomVO(1,"103,205,325,452,225");		

				List<RandomVO> listOfRandomValues = new ArrayList<RandomVO>();
				listOfRandomValues.add(random1);
			 	  
				int id;
				int data=0;
				String numbers = null;
				for(RandomVO getData : listOfRandomValues){
					 id = getData.getPosition();
					 numbers = getData.getRandomNums();
				}
					int i=1;
					List<Integer> li = new ArrayList<Integer>();
					ArrayList<Integer> position = new ArrayList<Integer>();
					for(String randomNum: numbers.split(",",0)){
					
					li.add( Integer.valueOf(randomNum));
					i++;
							
					position.add(li.indexOf(Integer.valueOf(randomNum)));
					
					}
					Collections.sort(li);
					System.out.println("Position of value ");
					System.out.println(position);
					System.out.println("Input Data: ");
					System.out.println(li);

					GenerateRandom convertData = new GenerateRandom();
					 List<Integer>  getRandomData = convertData.getRandomData(li);
					 System.out.println("Output Data");
					 System.out.println(getRandomData);
		  				
		return getRandomData;
	}

	@RequestMapping(value = "/randomData/{id}", method = RequestMethod.GET,headers="Accept=application/json")
	public RandomVO getRandomDataById(@PathVariable int id)
	{
		List<RandomVO> listOfValues = new ArrayList<RandomVO>();
		listOfValues=createRandomList();

		for (RandomVO randomVO: listOfValues) {
			if(randomVO.getPosition()==id)
				return randomVO;
		}
		
		return null;
	}

// Utiliy method to create Random list.
	public List<RandomVO> createRandomList()
	{
		RandomVO random1=new RandomVO(1,"103,205,325,452,225");		

		List<RandomVO> listOfRandomValues = new ArrayList<RandomVO>();
		listOfRandomValues.add(random1);
		return listOfRandomValues;
	}

}
